#include <iostream>
#include <string>
#include <cstdio>

#include "Alumno.h"

bool validarLegajo(int numeroLegajo){

    bool existe = false;
    Alumno alumnoLeido;
    /// LEER EN ARCHIVO
    FILE *p;
    /// MODO APERTURA
    p = fopen("alumno.dat", "rb");
    /// VALIDO APERTURA
    if(p== NULL){
        exit(1);
    }
    /// LEER EN EL ARCHIVO
    while(fread(&alumnoLeido, sizeof (Alumno), 1, p)==true){
        if(alumnoLeido.getLegajo()==numeroLegajo){
            existe=true;
            break;
        }
    }
    /// CERRAR ARCHIVO
    fclose(p);
    return existe;
}

int cantidadBytes(){
    int cantidad;
    FILE *p;
    p = fopen("alumno.dat", "rb");
    if(p==NULL){
        exit(1);
    }
    fseek(p,0,SEEK_END);
    cantidad = ftell(p);

    return cantidad;
}

using namespace std;

int main()
{

    /**
    /// CREAR ARCHIVO
    FILE *p;
    /// MODO APERTURA
    p = fopen("alumno.dat", "ab");
    /// VALIDO CREACION
    if(p== NULL){
        exit(1);
    }
    /// CERRAR ARCHIVO
    fclose(p);
    */


    Alumno obj;
    /**
    obj.cargarAlumno();
    if(!validarLegajo(obj.getLegajo())){
        if(obj.grabarAlumno()){
            cout << "Alumno agregado exitosamente!!!" << endl;
        }
        else{
            cout << "ERROR, pasaron cosas!!!" << endl;
        }
    }
    else{
        cout << "Existe" << endl;
    }
*/


    /**
    /// ESCRIBIR EN ARCHIVO
    FILE *p;
    /// MODO APERTURA
    p = fopen("alumno.dat", "ab+");
    /// VALIDO CREACION
    if(p== NULL){
        exit(1);
    }
    /// ESCRIBIR EN EL ARCHIVO
    fwrite(&alu1, sizeof (Alumno), 1, p);

    /// CERRAR ARCHIVO
    fclose(p);

    */

    /**
    cout << endl;
    cout << "LISTADO DE ALUMNOS" << endl;
    obj.leerAlumnos();
    */

    cout << "Bytes: " << sizeof(Alumno) << endl;
    cout << "Total bytes: " << cantidadBytes() << endl;

    obj.leerUnAlumno(3);










    return 0;
}
