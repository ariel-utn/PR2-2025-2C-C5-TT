#ifndef ALUMNO_H_INCLUDED
#define ALUMNO_H_INCLUDED
#include <iostream>
///#include <cstring> /// PARA C
///#include <string>  /// PARA C++

using namespace std;

class Alumno{

private:
    /// PROPIEDADES - ATRIBUTOS - CARACTERISTICAS
    int _legajo;
    char _nombre[30];
    char _apellido[30];
    bool _estado;

public:
    /// CONSTRUCTOR/ES
    Alumno();
    Alumno(int legajo, string nombre, string apellido, bool estado);



    /// METODOS - ACCIONES - EVENTOS
    void cargarAlumno();
    void mostrarAlumno();
    ///string toString();

    /// SETTERS
    void setLegajo(int legajo);
    void setNombre(string nombre);
    void setApellido(string apellido);
    void setEstado(bool estado);

    /// GETTERS
    int getLegajo();

    /// ARCHIVO
    bool grabarAlumno();
    void leerAlumnos(); /// TODOS
    void leerUnAlumno(int pos);


    /// DESTRUCTOR
    ~Alumno();

};

#endif // ALUMNO_H_INCLUDED
