#ifndef TARJETA_H_INCLUDED
#define TARJETA_H_INCLUDED

class Tarjeta
{
private:


public:

};

#endif // TARJETA_H_INCLUDED
