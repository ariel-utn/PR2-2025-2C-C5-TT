#ifndef VIAJES_H_INCLUDED
#define VIAJES_H_INCLUDED
#include <iostream>

class Viajes
{
private:
    char _numeroViaje[5];
    char _numeroTarjeta[6];
    int _medioTransporte; ///(1 - Colectivo, 2 - Subte, 3 - Tren)
    int _mesViaje;
    float _importeViaje;


public:
    /// CONSTRUCTOR
    Viajes();

    /// SETTERS
//    void setNumeroViaje(std::string numeroViaje);
//    void setNumeroTarjeta(std::string numeroTarjeta);
//    void setMedioTransporte(int medioTransporte); ///(1 - Colectivo, 2 - Subte, 3 - Tren)
//    void setMesViaje(int mesViaje);
//    void setImporteViaje(int importeViaje);

///    GETTERS
    std::string getNumeroViaje();
    std::string getNumeroTarjeta();
    int getMedioTransporte(); ///(1 - Colectivo, 2 - Subte, 3 - Tren)
    int getMesViaje();
    float getImporteViaje();

    /// METODOS
    /// void cargarViaje();
    void mostrarViaje();
    void mostrarViaje(int pos);

    /// ARCHIVOS
    void leerDeDisco();
    void leerDeDisco(int pos);


};

#endif // VIAJES_H_INCLUDED
