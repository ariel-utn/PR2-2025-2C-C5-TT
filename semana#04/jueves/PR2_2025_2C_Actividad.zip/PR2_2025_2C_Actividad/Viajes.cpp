#include "Viajes.h"
#include <iostream>
#include <string>
#include <cstring>
#include <stdio.h>

/// CONSTRUCTOR
Viajes::Viajes()
{

}

/// METODOS
/// void Viajes::cargarViaje();
void Viajes::mostrarViaje()
{
    std::cout << "=======INFO VIAJE=======" << std::endl;
    std::cout << "Numero de viaje: ";
    std::cout << getNumeroViaje()<< std::endl;
    std::cout << "Numero de tarjeta: ";
    std::cout << getNumeroTarjeta()<< std::endl;
    std::cout << "Medio de transporte: ";
    std::cout << getMedioTransporte()<< std::endl;
    std::cout << "Mes de viaje: ";
    std::cout << getMesViaje()<< std::endl;
    std::cout << "Importe $: ";
    std::cout << getImporteViaje()<< std::endl;
    std::cout << std::endl;

}

///    GETTERS
std::string Viajes::getNumeroViaje() {
    return _numeroViaje;
}
std::string Viajes::getNumeroTarjeta() {
    return _numeroTarjeta;
}
int Viajes::getMedioTransporte() {
    return _medioTransporte;
}
int Viajes::getMesViaje() {
    return _mesViaje;
}
float Viajes::getImporteViaje() {
    return _importeViaje;
}

    /// ARCHIVOS
void Viajes::leerDeDisco(){
    /// APERTURA
    FILE *p;
    p = fopen("Viajes.dat","rb");
    /// VALIDACION APERTURA
    if(p==NULL){
        exit(1);
    }
    /// LEER TODOS
    while(fread(this, sizeof(Viajes), 1, p)){
        this->mostrarViaje();
    }
    /// CERRAR ARCHIVO
    fclose(p);
}

void Viajes::leerDeDisco(int pos){
    /// APERTURA
    FILE *p;
    p = fopen("Viajes.dat","rb");
    /// VALIDACION APERTURA
    if(p==NULL){
        exit(1);
    }
    /// LEER DE A UNO
    fseek(p, sizeof(Viajes)*pos, SEEK_SET);
    fread(this, sizeof(Viajes), 1, p);
    /// CERRAR ARCHIVO
    fclose(p);
}

void Viajes::mostrarViaje(int pos){
    leerDeDisco(pos);
    this->mostrarViaje();
}
