#ifndef FUNCIONES_H_INCLUDED
#define FUNCIONES_H_INCLUDED
#include "Viajes.h"

int obtenerCantidadRegistros(){
    int cantidad;
    FILE *p;
    p = fopen("Viajes.dat", "rb");
    if(p==NULL){
        exit(1);
    }
    fseek(p,0,SEEK_END);
    cantidad = ftell(p);

    return cantidad/sizeof(Viajes);
}



#endif // FUNCIONES_H_INCLUDED
