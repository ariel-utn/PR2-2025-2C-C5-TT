#include <iostream>
#include "Viajes.h"
#include "Tarjeta.h"
#include "funciones.h"

using namespace std;

int main()
{
    Viajes obj;
    obj.leerDeDisco();

    /// EL VIAJE CON MENOR IMPORTE. MOSTRAR TODO EL REGISTRO.

    /// OBTENGO LA CANTIDAD DE VIAJES
    int cantidadRegistros;
    cantidadRegistros=obtenerCantidadRegistros();

    int minimo;
    int pos;
    for(int i = 0; i < cantidadRegistros; i++){
        obj.leerDeDisco(i);
        if(i==0 ||  obj.getImporteViaje()< minimo){
            minimo = obj.getImporteViaje();
            pos = i;
        }
    }

    cout << "----PTO 2-------"<< endl;
    /// MOSTRAR
    obj.mostrarViaje(pos);

    return 0;
}
