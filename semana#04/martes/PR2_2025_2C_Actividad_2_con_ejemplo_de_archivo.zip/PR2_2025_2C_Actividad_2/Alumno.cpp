#include <iostream>
#include "Alumno.h"
#include <string>
#include <cstring>

using namespace std;


/// DESARROLLO

/// CONSTRUCTOR/ES
Alumno::Alumno()
{
    _legajo = -1;
//    _nombre = "sin_nombre";
    strcpy(_nombre, "sin_nombre");
//    _apellido = "sin_apellido";
    strcpy(_apellido, "sin_apellido");
    _estado = false;
}

Alumno::Alumno(int legajo, string nombre, string apellido, bool estado){
    setLegajo(legajo);
    setNombre(nombre);
    setApellido(apellido);
    setEstado(estado);
}

/// METODOS - ACCIONES - EVENTOS
/// RESOLUCION DE AMBITO ::

void Alumno::cargarAlumno()
{
    string nombre;
    string apellido;

    /// ENTERO
    cout << "Legajo: ";
    cin >> _legajo;

    cin.ignore();

    cout << "Nombre: ";
    getline(cin,nombre);
    strcpy(_nombre,nombre.c_str());

    cout << "Apellido: ";
    getline(cin,apellido);
    strcpy(_apellido,apellido.c_str());

    cout << "Estado: ";
    cin >> _estado;
}

void Alumno::mostrarAlumno()
{
    cout << "Legajo: " << _legajo << endl;
    cout << "Nombre: " << _nombre << endl;
    cout << "Apellido: " << _apellido << endl;
    cout << "Estado: ";
    if(_estado){
        cout << "Regular" << endl;
    }
    else{
        cout << "Libre" << endl;
    }
    /// IF TERNARIO
}

/// DESTRUCTOR
Alumno::~Alumno()
{
    cout << "Fin del objeto (; Adiosss " << _nombre << endl;

}

/// SETTERS
void Alumno::setLegajo(int legajo)
{
    if(legajo > 0){
        _legajo = legajo;
    }
    else{
        _legajo = -1;
    }
}

void Alumno::setNombre(string nombre)
{
    if(nombre.size() > 0){
        strcpy(_nombre, nombre.c_str());
    }
    else{
        strcpy(_nombre,"no_ingreso_nombre");
    }

}
void Alumno::setApellido(string apellido)
{
    if(apellido.size() > 0){
        strcpy(_apellido, apellido.c_str());
    }
    else{
        strcpy(_apellido,"no_ingreso_apellido");
    }
}

void Alumno::setEstado(bool estado)
{
    _estado = estado;
}

/**
string Alumno::toString(){
    return  "Nombre: " + _nombre + "\n" + "Apellido: " + _apellido + "\n" + "Legajo: " + to_string(_legajo) + "\n" + "Estado: " + (_estado ? "REGULAR" : "LIBRE");
}*/
