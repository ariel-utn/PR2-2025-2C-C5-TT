#include <iostream>
#include <string>
#include <cstdio>

#include "Alumno.h"

using namespace std;

int main()
{
    /**
    int edad;
    cin >> edad;

    cin.ignore();

    string nombre;
    getline(cin, nombre);

    cout << edad;
    cout << endl;
    cout << nombre;
    */

//    Alumno alu1(1234,"Juan Manuel", "Lopez", 1);
//    alu1.mostrarAlumno();


    /**
    /// CREAR ARCHIVO
    FILE *p;
    /// MODO APERTURA
    p = fopen("alumno.dat", "ab");
    /// VALIDO CREACION
    if(p== NULL){
        exit(1);
    }
    /// CERRAR ARCHIVO
    fclose(p);
    */

    /**
    /// ESCRIBIR EN ARCHIVO
    FILE *p;
    /// MODO APERTURA
    p = fopen("alumno.dat", "ab+");
    /// VALIDO CREACION
    if(p== NULL){
        exit(1);
    }
    /// ESCRIBIR EN EL ARCHIVO
    fwrite(&alu1, sizeof (Alumno), 1, p);

    /// CERRAR ARCHIVO
    fclose(p);

    */

    Alumno alumnoLeido;
    /// LEER EN ARCHIVO
    FILE *p;
    /// MODO APERTURA
    p = fopen("alumno.dat", "rb");
    /// VALIDO CREACION
    if(p== NULL){
        exit(1);
    }
    /// LEER EN EL ARCHIVO
    fread(&alumnoLeido, sizeof (Alumno), 1, p);
    alumnoLeido.mostrarAlumno();

    /// CERRAR ARCHIVO
    fclose(p);






    return 0;
}
