#include <iostream>
#include "Menu.h"
#include "ClsGestorProducto.h"
#include "Producto.h"

void Menu::mostrar()
{
    system("cls");
    std::cout << "====MENU DE OPCIONES====" << std::endl;
    std::cout << std::endl;
    std::cout << "1- AGREGAR PRODUCTO" << std::endl;
    std::cout << "2- MOSTRAR PRODUCTO POR ID" << std::endl;
    std::cout << "3- LISTAR TODOS LOS PRODUCTOS  " << std::endl;
    std::cout << "4- MODIFICAR PRODUCTOS  " << std::endl;
    std::cout << std::endl;
    std::cout << std::endl;
    std::cout << "9- SALIR  " << std::endl;
}
void Menu::obtenerOpcion()
{
    std::cout << "INGRESE UNA OPCION: " << std::endl;
    std:: cin >> _opcion;
}

void Menu::opcionesMenu()
{

    switch(_opcion)
    {
    case 1:
    {
        Producto reg;
        GestorProducto gestorProducto;
        bool grabo;
        system("cls");
        std::cout << "=== AGREGAR PRODUCTO ===" << std::endl;

        /// VALIDAR QUE EL PRODUCTO NO EXISTA

        gestorProducto.CargarUnProducto(reg);
        grabo = gestorProducto.guardarEnDiscoProducto(reg);
        if(grabo)
        {
            std::cout << "PRODUCTO AGREGADO EXITOSAMENTE" << std::endl;
        }
        else
        {
            std::cout << "ERRO: no se pudo grabar el producto" << std:: endl;
        }
    }
    break;
    case 2:
    {
        Producto reg;
        GestorProducto gestorProducto;
        system("cls");
        std::cout << "=== MOSTRAR PRODUCTO ===" << std::endl;
        int id, pos;
        std::cout << "INGRESE ID DEL PRODUCTO:";
        std::cin >> id;
        pos = gestorProducto.buscarProductoPorId(pos);
        if(pos!=-1)
        {
            std::cout << "NO EXISTE EL ID INGRESADO" << std::endl;
        }
        else
        {
            pos = gestorProducto.buscarProductoPorId(id);
            reg = gestorProducto.leerProducto(pos);
            /// MOSTRAR PRODUCTO
            gestorProducto.MostrarUnProducto(reg);
        }
        system("pause");
    }
    break;
    case 3:
    {
        system("cls");
        GestorProducto gestorProducto;
        std::cout << "=== LISTADO DE PRODUCTOS ===" << std::endl;
        gestorProducto.listarTodosLosProductos();
        system("pause");
    }
    break;
    case 4:
    {
        Producto reg;
        GestorProducto gestorProducto;
        system("cls");
        std::cout << "=== MODIFICAR PRODUCTOS ===" << std::endl;
        /// Localizar la posici�n del registro que se desea modificar.
        std::cout << "=== BUSCAR PRODUCTO POR ID ===" << std::endl;
        int id, pos;
        std::cout << "Ingrese el id del producto:";
        std::cin >> id;
        pos = gestorProducto.buscarProductoPorId(id);
        std::cout << "POS: " << pos << std::endl;

        /// VALIDAR QUE ID != -1
        /// Copiar el registro a una variable de memoria.
        reg = gestorProducto.leerProducto(pos);

        /// MOSTRAR PRODUCTO
        gestorProducto.MostrarUnProducto(reg);

        /// Asignar los nuevos valores a los campos correspondientes.
        bool estado, grabo;
        std::cout << "Ingrese estado [1-ACTIVO 0-INACTIVO]: ";
        std::cin >> estado;
        reg.setEstado(estado);

        /// Escribir el registro modificado de nuevo en la misma posici�n.
        grabo = gestorProducto.guardarEnDiscoProducto(reg,pos);
        if(grabo)
        {
            std::cout << "MODIFICACION EXITOSA" << std::endl;
        }
        else
        {
            std::cout << "ERROR" << std::endl;
        }
        system("pause");
    }
    break;
    case 9:
    {
        _salir=true;
        std::cout << "SALIMOS DEL SISTEMA" << std::endl;
        system("pause");
    }
    break;
    default:
        std::cout << "ERROR!!!" << std::endl;

    }
}
void Menu::ejecutarMenu()
{

    while(!_salir)
    {
        mostrar();
        obtenerOpcion();
        opcionesMenu();
    }
}

Menu::Menu()
{
    _salir=false;
}
