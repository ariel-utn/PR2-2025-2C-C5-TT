#ifndef CLSGESTORPRODUCTO_H_INCLUDED
#define CLSGESTORPRODUCTO_H_INCLUDED

#include"Producto.h"
#include<string>

class GestorProducto
{
public:

    void CargarUnProducto(Producto &); // Agregar un nuevo producto al sistema.
    void MostrarUnProducto(Producto); // Visualizar los datos de un producto espec�fico por su id.


    /// MANIPULACION DE ARCHIVOS
    bool guardarEnDiscoProducto(Producto);
    void listarTodosLosProductos();
    int buscarProductoPorId(int);
    void leerUnRegistro(int);


    GestorProducto();

private:
    std::string _rutaDireccion;
};

#endif // CLSGESTORPRODUCTO_H_INCLUDED
