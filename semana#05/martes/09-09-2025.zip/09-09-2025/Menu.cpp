#include <iostream>
#include "Menu.h"
#include "ClsGestorProducto.h"
#include "Producto.h"

void Menu::mostrar()
{
    system("cls");
    std::cout << "====MENU DE OPCIONES====" << std::endl;
    std::cout << std::endl;
    std::cout << "1- CARGAR PRODUCTO      " << std::endl;
    std::cout << "2- MOSTRAR PRODUCTO     " << std::endl;
    std::cout << "3- AGREGAR EN DISCO UN PRODUCTO  " << std::endl;
    std::cout << "4- LISTAR TODOS LOS PRODUCTOS  " << std::endl;
    std::cout << std::endl;
    std::cout << "9- AGREGAR UN PRODUCTO  " << std::endl;
}
void Menu::obtenerOpcion()
{
    std::cout << "INGRESE UNA OPCION: " << std::endl;
    std:: cin >> _opcion;
}

void Menu::opcionesMenu(GestorProducto gestorProducto, Producto &producto)
{

    switch(_opcion)
    {
    case 1:
    {
        ///
        std::cout << "CARGO PRODUCTO" << std::endl;
        gestorProducto.CargarUnProducto(producto);
    }
    break;
    case 2:
    {
        ///
        std::cout << "MUESTRO PRODUCTO" << std::endl;
        gestorProducto.MostrarUnProducto(producto);
        system("pause");
    }
    break;
    case 3:
    {
        if(gestorProducto.guardarEnDiscoProducto(producto)){
            std::cout << "Registro agregado exitosamente";
        }
        system("pause");
    }
    case 4:
    {
        std::cout << "=== LISTADO DE PRODUCTOS ===" << std::endl;
        gestorProducto.listarTodosLosProductos();
        system("pause");
    }
    break;
    case 9:
    {
        _salir=true;
        std::cout << "SALIMOS DEL SISTEMA" << std::endl;
        system("pause");
    }
    break;
    default:
        std::cout << "ERROR!!!" << std::endl;

    }

}
void Menu::ejecutarMenu(GestorProducto gestorProducto, Producto producto)
{

    while(!_salir)
    {
        mostrar();
        obtenerOpcion();
        opcionesMenu(gestorProducto,producto);
    }
}

Menu::Menu()
{
    _salir=false;
}
