#include <iostream>
#include "Alumno.h"

using namespace std;

int main()
{
    /**
    Alumno obj[3];
//    cout << "--CARGAR ALUMNOS--" << endl;
//    for(int i = 0; i < 3; i++)
//        obj[i].cargarAlumno();

    cout << endl << endl;

    cout << "--MOSTRAR ALUMNOS--" << endl;
    for(int i = 0; i < 3; i++)
        obj[i].mostrarAlumno();



    obj.cargarAlumno();

    cout << "-------" << endl;
    obj.mostrarAlumno();
    */

    Alumno alu1;  /// CONSTRUCTOR POR DEFECTO

    Alumno alu2(1,"Agustin","Cejas",true); /// CONSTRUCTOR CON PARAMETROS


    cout << "--MOSTRAR ALUMNOS--" << endl;
    alu1.mostrarAlumno();

    cout << endl << endl;
    alu2.mostrarAlumno();

    cout << endl << endl;

    cout << alu2.toString();
    cout << endl << endl;

    return 0;
}
