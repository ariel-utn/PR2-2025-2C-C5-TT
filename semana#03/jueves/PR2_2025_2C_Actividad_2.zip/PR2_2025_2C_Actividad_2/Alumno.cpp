#include <iostream>
#include "Alumno.h"
#include <string>

using namespace std;


/// DESARROLLO

/// CONSTRUCTOR/ES
Alumno::Alumno()
{
    _legajo = -1;
    _nombre = "sin_nombre";
    _apellido = "sin_apellido";
    _estado = false;
}

Alumno::Alumno(int legajo, string nombre, string apellido, bool estado){
    setLegajo(legajo);
    setNombre(nombre);
    setApellido(apellido);
    setEstado(estado);
}

/// METODOS - ACCIONES - EVENTOS
/// RESOLUCION DE AMBITO ::

void Alumno::cargarAlumno()
{
    cout << "Legajo: ";
    cin >> _legajo;

    cout << "Nombre: ";
    cin >> _nombre;

    cout << "Apellido: ";
    cin >> _apellido;

    cout << "Estado: ";
    cin >> _estado;
}

void Alumno::mostrarAlumno()
{
    cout << "Legajo: " << _legajo << endl;
    cout << "Nombre: " << _nombre << endl;
    cout << "Apellido: " << _apellido << endl;
    cout << "Estado: ";
    if(_estado){
        cout << "Regular" << endl;
    }
    else{
        cout << "Libre" << endl;
    }
    /// IF TERNARIO
}

/// DESTRUCTOR
Alumno::~Alumno()
{
    cout << "Fin del objeto (; (; Adiosss " << _nombre << endl;

}

/// SETTERS
void Alumno::setLegajo(int legajo)
{
    if(legajo > 0){
        _legajo = legajo;
    }
    else{
        _legajo = -1;
    }
}

void Alumno::setNombre(string nombre)
{
    if(nombre.size() > 0){
        _nombre = nombre;
    }
    else{
        _nombre = "no_ingreso_nombre";
    }

}
void Alumno::setApellido(string apellido)
{
    if(apellido.size() > 0){
        _apellido = apellido;
    }
    else{
        _apellido = "no_ingreso_apellido";
    }
}

void Alumno::setEstado(bool estado)
{
    _estado = estado;
}

string Alumno::toString(){
    return  "Nombre: " + _nombre + "\n" + "Apellido: " + _apellido + "\n" + "Legajo: " + to_string(_legajo) + "\n" + "Estado: " + (_estado ? "REGULAR" : "LIBRE");
}
