#ifndef ALUMNO_H_INCLUDED
#define ALUMNO_H_INCLUDED
#include <iostream>
///#include <cstring> /// PARA C
///#include <string>  /// PARA C++

using namespace std;

class Alumno{

private:
    /// PROPIEDADES - ATRIBUTOS - CARACTERISTICAS
    int _legajo;
    string _nombre;
    string _apellido;
    bool _estado;

public:
    /// CONSTRUCTOR/ES
    Alumno();
    Alumno(int legajo, string nombre, string apellido, bool estado);



    /// METODOS - ACCIONES - EVENTOS
    void cargarAlumno();
    void mostrarAlumno();
    string toString();

    /// SETTERS
    void setLegajo(int legajo);
    void setNombre(string nombre);
    void setApellido(string apellido);
    void setEstado(bool estado);


    /// DESTRUCTOR
    ~Alumno();

};

#endif // ALUMNO_H_INCLUDED
