#ifndef CLSGESTORPRODUCTO_H_INCLUDED
#define CLSGESTORPRODUCTO_H_INCLUDED

#include"Producto.h"
#include<string>

class GestorProducto
{
public:

    void CargarUnProducto(Producto &); // Agregar un nuevo producto al sistema.
    void MostrarUnProducto(Producto); // Visualizar los datos de un producto espec�fico por su id.


    /// MANIPULACION DE ARCHIVOS
    bool guardarEnDiscoProducto(Producto);
    void listarTodosLosProductos();
    int buscarProductoPorId(int); /// El entero representa el id del producto
    void buscarProductoPorCategoria(std::string);
    void leerUnRegistro(int);
    Producto leerProducto(int); /// El entero representa la posicion del registro en el archivo
    bool guardarEnDiscoProducto(Producto,int);

    /// OBTENER_PROXIMO_ID()
    void getPuntoCinco();
    void getPuntoCuatro();


    GestorProducto();

private:
    std::string _rutaDireccion;
};

#endif // CLSGESTORPRODUCTO_H_INCLUDED
