#include <iostream>
#include "Menu.h"
#include "ClsGestorProducto.h"
#include "Producto.h"

void Menu::mostrar()
{
    system("cls");
    std::cout << "====MENU DE OPCIONES====" << std::endl;
    std::cout << std::endl;
    std::cout << "1- AGREGAR PRODUCTO" << std::endl;
    std::cout << "2- MOSTRAR PRODUCTO POR ID" << std::endl;
    std::cout << "3- LISTAR TODOS LOS PRODUCTOS  " << std::endl;
    std::cout << "4- MODIFICAR PRODUCTOS  " << std::endl;
    std::cout << "5- FILTRAR POR CATEGORIA  " << std::endl;
    std::cout << std::endl;
    std::cout << std::endl;
    std::cout << "9- SALIR  " << std::endl;
}
void Menu::obtenerOpcion()
{
    std::cout << "INGRESE UNA OPCION: " << std::endl;
    std:: cin >> _opcion;
}

void Menu::opcionesMenu()
{

    switch(_opcion)
    {
    case 1:
    {
        Producto reg;
        GestorProducto gestorProducto;
        bool grabo;
        system("cls");
        std::cout << "=== AGREGAR PRODUCTO ===" << std::endl;

        /// VALIDAR QUE EL PRODUCTO NO EXISTA

        gestorProducto.CargarUnProducto(reg);
        grabo = gestorProducto.guardarEnDiscoProducto(reg);
        if(grabo)
        {
            std::cout << "PRODUCTO AGREGADO EXITOSAMENTE" << std::endl;
        }
        else
        {
            std::cout << "ERRO: no se pudo grabar el producto" << std:: endl;
        }
    }
    break;
    case 2:
    {
        Producto reg;
        GestorProducto gestorProducto;
        system("cls");
        std::cout << "=== MOSTRAR PRODUCTO ===" << std::endl;
        int id, pos;
        std::cout << "INGRESE ID DEL PRODUCTO:";
        std::cin >> id;
        pos = gestorProducto.buscarProductoPorId(id);
        if(pos==-1)
        {
            std::cout << "NO EXISTE EL ID INGRESADO" << std::endl;
        }
        else
        {
            reg = gestorProducto.leerProducto(pos);
            /// MOSTRAR PRODUCTO
            gestorProducto.MostrarUnProducto(reg);
        }
        system("pause");
    }
    break;
    case 3:
    {
        system("cls");
        GestorProducto gestorProducto;
        std::cout << "=== LISTADO DE PRODUCTOS ===" << std::endl;
        gestorProducto.listarTodosLosProductos();
        system("pause");
    }
    break;
    case 4:
    {
        _gestorProducto.getPuntoCuatro();
    }
    break;
    case 5:{
        _gestorProducto.getPuntoCinco();
    }
    break;

    case 9:
    {
        _salir=true;
        std::cout << "SALIMOS DEL SISTEMA" << std::endl;
        system("pause");
    }
    break;
    default:
        std::cout << "ERROR!!!" << std::endl;

    }
}
void Menu::ejecutarMenu()
{

    while(!_salir)
    {
        mostrar();
        obtenerOpcion();
        opcionesMenu();
    }
}

Menu::Menu()
{
    _salir=false;
}
